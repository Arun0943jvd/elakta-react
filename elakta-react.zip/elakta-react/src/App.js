import React, { useState } from "react";

import * as elementValues from "./resource";
import Modal from "react-modal";
import DatePicker from "react-datepicker";
import "./App.css";

Modal.setAppElement("#root");

export default function App() {
  
  const [isOpen, setIsOpen] = useState(false);
  const [showSelected,setShowSelected] = useState(false);
  const [startDate, setStartDate] = useState(new Date());


  
  function toggleModal() {
    setIsOpen(!isOpen);
    setShowSelected(!showSelected);
  }

  // // eslint-disable-next-line no-undef
  // isWeekday = (date: Date) => {
  //   const day = date.getDay()
  //   return day !== 0 && day !== 6
  // }

 
  return (

    <div className="ek-padding container">
      <button class="btn ek-button-color" onClick={toggleModal}>{elementValues.buttonText}</button>

      <Modal
        isOpen={isOpen}
        onRequestClose={toggleModal}
        contentLabel="My dialog"
      >
        <div><h3>Pop up modal</h3>
        <DatePicker selected={startDate}  dateFormat="MM-dd-yyyy" placeholderText="Select a Date" minDate={new Date(2021, 3)} 
          maxDate={new Date("12-31-2022")} onChange={date => setStartDate(date)}  className="select-btn selectbtn-picker" />
           
        </div>
      
        <button class="btn ek-button-color" onClick={toggleModal}>{elementValues.confirmButtonText}</button>
      </Modal>


    </div>
  );
}