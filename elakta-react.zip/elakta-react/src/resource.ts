export const buttonText = 'Schedule Migration';
export const confirmButtonText = 'Confirm';
export const checkText = 'Dynamic Checkbox';

export const checkBoxes = [
    { id: 'facility_001', value: 'Facility 001', name: 'facility_001', isChecked: false },
    { id: 'facility_002', value: 'Facility 002', name: 'facility_002', isChecked: false },
    { id: 'facility_003', value: 'Facility 003', name: 'facility_003', isChecked: false },
    { id: 'facility_004', value: 'Facility 004', name: 'facility_004', isChecked: false },
    { id: 'facility_005', value: 'Facility 005', name: 'facility_005', isChecked: false }
];
